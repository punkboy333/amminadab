﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label3.Text = "Samu's answer";
            label2.Text = "Send Msg";
            label1.Text = "Conection ready";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            textBox1.Text = "" + openFileDialog1.FileName.ToString();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {
           
        }
        bool button=false; int port = 0; Thread ctThread;
        private void button3_Click(object sender, EventArgs e)
        {

            if (!button)
            {
                clientSocket = new System.Net.Sockets.TcpClient();
                
                if (textBox3.Text.Length > 0)
                    port = Convert.ToInt32(textBox3.Text);
                else
                    label1.Text = "Bad Ip or port";

                if (Connect1(textBox2.Text, port))
                {
                    ip = textBox2.Text;
                    label1.Text = "Conected ok";
                    serverStream = clientSocket.GetStream();
                    //getMsg();
                   // clientSocket.Close();
                    ctThread = new Thread(getMsg);
                    ctThread.Start();
                    lastrecive = "";
                    recive = "";
                    //clientSocket.Close();
                    timer1.Start();
                    button = true;
                    button3.Text = "Dissconect";
                    
                   // sendMsg();
                }
            }
            else
            {
                button3.Text = "Connect";
                timer1.Stop();
               
                button = false;
                listBox1.Items.Clear();
            }

        }
        public string s="alma";
        NetworkStream serverStream;

        string lastrecive;


        private void timer1_Tick(object sender, EventArgs e)
        {



            if (recive.Length> 1 && recive!=lastrecive)
            {
                listBox1.Items.Add(recive );
                
                //textBox5.Text += ;
                lastrecive = recive;
            }
            if (listBox1.Items.Count > 11)
                    listBox1.Items.RemoveAt(0);
            // serverStream.Close();
        }

        System.Net.Sockets.TcpClient clientSocket;

        public bool Connect1(String ip , int port)
        {
            try
            {

                    clientSocket.Connect(ip, port);
                    label1.Text = "Client Socket Program - Server Connected ...";
                
                return true;
            }
            catch {
                label1.Text = "Conection failed to "+textBox2.Text+" "+port;
                return false;
            }

        }
        byte[] incomingBuffer = new byte[4096];
        char[] receivedChars = new char[4096];
        string recive;
        string ip;
        public void getMsg()
        {
           
            
            while (button)
            {
                System.Net.Sockets.TcpClient clientSocket2 = new TcpClient();
                NetworkStream stream;
                try
                { 
                   
                        clientSocket2.Connect(ip, port);
                       stream = clientSocket2.GetStream();


                        StringBuilder stringBuilder = new StringBuilder();
                        int buffSize = 0;
                        byte[] inStream = new byte[10025];
                        buffSize = clientSocket2.ReceiveBufferSize;
                        stream.Read(inStream, 0, 4096);
                       //serverStream.Flush();
                        string returndata = System.Text.Encoding.ASCII.GetString(inStream);
                        stream.ReadTimeout = 100;

                        recive = returndata;
                        //serverStream.Close();
                        //sendMsg();
                       stream.Close();
                       clientSocket2.Close();
                    }

                
                catch 
                {
                    ;
                } 
            }
           
        }
        
        public void sendMsg() {
            try
            {
                System.Net.Sockets.TcpClient clientSocket2 = new TcpClient();
                clientSocket2.Connect(ip, port);
                NetworkStream stream = clientSocket2.GetStream(); 
                byte[] outStream = System.Text.Encoding.ASCII.GetBytes(textBox1.Text );


                    stream.Write(outStream, 0, outStream.Length);
                stream.Flush();
                stream.Close();
                    send = false;
                    textBox4.Text = "Send OK";
               // serverStream.Close();
            }
            catch 
            {
               ;
            }

        }
        
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
        bool send = false;
        private void button2_Click(object sender, EventArgs e)
        {
            send = true;
            sendMsg();
        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
